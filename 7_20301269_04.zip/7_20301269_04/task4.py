from queue import PriorityQueue
file=open('input4.txt')
file=file.read()
f1=file.split('\n')
for x in range(len(f1)):
    if x==0:
        f1[x]=int(f1[x])
    elif f1[x] !='':
        b=f1[x].split(' ')
        f1[x]=[]
        for x1 in b:
            x1=int(x1)
            f1[x]=f1[x]+[x1]
    else:
        f1.remove(f1[x])
g=[]
x1=0
sources=[]
for x in range(0,f1[0]):
    x1=x1+1
    if f1[x1][1]==0:
        g1={f1[x1][0]:f1[x1][1]}
        x1=x1+1
        sources.append(f1[x1][0])
    else:
        g1={}
        nodes=f1[x1][0]
        for x2 in range(0,f1[x1][1]):
            x1=x1+1
            u=f1[x1][0]
            v=f1[x1][1]
            w=f1[x1][2]
            if u in g1:
                temp=[v,w]
                g1[u].append(temp)
            else:
                g1[u]=[]
                temp=[v,w]
                g1[u].append(temp)
        for y in range(1,nodes+1):
            if y not in g1.keys():
                g1[y]=[]
        x1=x1+1
        sources.append(f1[x1][0])
    g1=dict(sorted(g1.items()))
    g.append(g1)
def Dijkstra(Graph,source):
    dist=[10000]* len(Graph)
    dist[source-1]=0
    q=PriorityQueue()
    visited=[False]*len(Graph)
    prev=[0]*len(Graph)
    for key in Graph:
        if key!=source:
            dist[key-1]=-1
            prev[key-1]=0
        visited[key-1]=False
    q.put((-1*(dist[source-1]),source))
    while not q.empty():
        u=q.get()
        u=u[1]
        if visited[u-1]==True:
            continue
        visited[u-1]=True
        if type(Graph[u])==list:
            for x1 in Graph[u]:
                if dist[u-1]==0:
                    alt=x1[1]
                else:
                    alt=min(dist[u-1],x1[1])
                if alt>dist[x1[0]-1]:
                    dist[x1[0]-1]=alt
                    prev[x1[0]-1]=u
                    q.put((-1*(x1[1]),x1[0]))
        else:
            return dist,prev
    return dist,prev
fileout=open('output4.txt','w')
for x,y in zip(g,sources):
    q=Dijkstra(x,y)
    for x1 in q[0]:
        fileout.write(str(x1))
        fileout.write(' ')
    fileout.write('\n')