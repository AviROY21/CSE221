from queue import PriorityQueue


def Dijkstra(Graph, source):

    len_graph = max(Graph.keys())
    dist = [10000] * len_graph
    dist[source - 1] = 0

    prevs = [''] * len_graph
    prevs[source - 1] = f"{source}"

    Q = PriorityQueue()
    visited = [False] * len(Graph)
    for k in Graph:
        if k != source:
            dist[k - 1] = 10000
        visited[k - 1] = False

    Q.put((dist[source - 1], source))

    while not Q.empty():

        w, u = Q.get()

        visited[u - 1] = True

        for x in Graph[u]:
            if visited[x[0] - 1] == True:
                continue

            alt = w + x[1]

            if alt < dist[x[0] - 1]:
                dist[x[0] - 1] = alt
                Q.put((dist[x[0] - 1], x[0]))

                prevs[x[0] - 1] = prevs[u - 1] + f" {x[0]}"

    return prevs[len_graph - 1]
file = open('input1.txt', 'r')
file = file.read()
file = file.split('\n')

for i in range(len(file)):
    if i == 0:
        file[i] = int(file[i])
    elif file[i] != '':
        back = file[i].split(' ')
        file[i] = []
        for x in back:
            x = int(x)
            file[i] = file[i] + [x]

    else:
        file.remove(file[i])

#print(file)

graph = []
x = 0
for i in range(0, file[0]):
    x += 1
    if file[x][1] == 0:
        graph1 = {1: []}
    else:
        graph1 = {}
        for i in range(1, file[x][0] + 1):
            graph1[i] = []
        for x1 in range(0, file[x][1]):
            x += 1
            u = file[x][0]
            v = file[x][1]
            w = file[x][2]

            temp = [v, w]
            graph1[u].append(temp)
    graph.append(graph1)
Q = Dijkstra(graph[0], 1)
print(Q)
Q1 = Dijkstra(graph[1], 1)
print(Q1)
Q2 = Dijkstra(graph[2], 1)
print(Q2)
i1 = len(Q[0])
i2 = len(Q1[0])
i3 = len(Q2[0])
fileout = open('output1.txt', 'w')
fileout.write(str(Q[0][i1 - 1]))
fileout.write('\n')
fileout.write(str(Q1[0][i2 - 1]))
fileout.write('\n')
fileout.write(str(Q2[0][i3 - 1]))
fileout.write('\n')