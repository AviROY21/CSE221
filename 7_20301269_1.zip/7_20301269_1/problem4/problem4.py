def Multiply_matrix(a,b):
    global n
    c=[[0]*n for i in range(n)]
    for i in range(0,n,1):
        for j in range(0,n,1):
            for l in range(0,n,1):
                c[i][j]+=int(a[i][l])*int(b[l][j])
    return c
ifile=open('Downloads\\input4.txt','r')
ofile=open('Downloads\\output4.txt','w')
n=int(ifile.readline())

a = []
b = []
x = 0

while True:
    r=ifile.readline().strip()
    p=r.split(' ')
    if x==(2*n)+1:
        break
    k=0
    if x<n:
        a.append(p)
    elif x>n:
        b.append(p)
    x=x+1
c=Multiply_matrix(a,b)

for i in range(0,len(c),1):
    for j in range(0,len(c[i]),1):
        print(c[i][j],end=' ',file=ofile)
    print('',file=ofile)
ofile.close()