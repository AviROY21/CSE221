def paritychecker(word1):
        global evencount
        global oddcount
        global nopacount
        if '.' in word1:
            nopacount=nopacount+1
            return 'no parity'
        elif (int(word1)&1==0):
            evencount=evencount+1
            return 'even parity'
        else:
            oddcount=oddcount+1
            return 'odd parity'
def palindromechecker(word):
        global palincount
        global nonpalincount
        if word=="":
            nonpalincount=nonpalincount+1
            return 'not a palindrome'
        else:
            N=len(word)
            for j in range(0,N//2,1):
                if word[j]!=word[N-1-j]:
                    nonpalincount=nonpalincount+1
                    return 'not a palindrome'
            palincount=palincount+1
            return 'a palindrome'

evencount=0
oddcount=0
nopacount=0
palincount=0
nonpalincount=0
i=0

rdata= open('Downloads\\input.txt','r')
odata= open('Downloads\\\output.txt','w')
recdata= open('Downloads\\\record.txt','w')

while True:
    r = rdata.readline().strip()
    d=r.split(' ')
    print(d)
    if len(d)==1:
        break
    word1=d[0]
    word=d[1]
    print(d[0],'has',paritychecker(word1),'and',d[1],'is',palindromechecker(word),".",file=odata)
    i=i+1
c= evencount+oddcount+nopacount
print('Percentage of odd parity:',(oddcount/c)*100,'%',file=recdata)
print('Percentage of even parity:',(evencount/c)*100,'%',file=recdata)
print('Percentage of no parity:',(nopacount/c)*100,'%',file=recdata)
print('Percentage of palindrome:',(palincount/c)*100,'%',file=recdata)
print('Percentage of non-palindrome:',(nonpalincount/c)*100,'%',file=recdata)
rdata.close()
odata.close()
recdata.close()
