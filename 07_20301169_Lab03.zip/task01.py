import sys

sys.stdin = open("input.txt", "r")
sys.stdout = open("output1.txt","w")
numbers = int(input())

#Graph constructed by dictionary

thegraph = {}
destination = 0
nodes=0

for counter in range(0, numbers+1):
    if counter==0:
        continue
    element =list(map(int,input().split()))
    if counter == numbers:
        destination = element[0]
        #print(destination)
    if counter == 1:
        nodes= element[0]
    thegraph[element[0]] = element[1:]

print(thegraph)