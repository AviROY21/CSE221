import sys

sys.stdin = open("input.txt","r")
sys.stdout = open("output3.txt","w")
numbers = int(input(" "))

#Graph constructed by dictionary
graph = {}
endPoint = 0
nodes=0

for counter in range(0, numbers+1):
    if counter==0:
        continue
    elements =list(map(int,input().split()))

    if counter == numbers:
        endPoint = elements[0]
        #print(endPoint)

    if counter== 1:
        nodes = elements[0]
    graph[elements[0]] = elements[1:]

#DFS
Do_visited = [0]*numbers
Do_printed = []

def DFS_VISITED(graph, nodes):
    Do_visited[int(nodes)-1]= 1
    Do_printed.append(nodes)
    for eachnode in graph[nodes]:
        if Do_visited[eachnode - 1] != 1:
            DFS_VISITED(graph, eachnode)

def DFS(graph, endPoint):
    for nodes in graph.keys():
        if Do_visited[nodes-1]!=1:
            DFS_VISITED(graph, nodes)
    for counter in Do_printed:
        if counter!= endPoint:
            print(counter,end=" ")
        else:
            print(counter)
            break

DFS(graph,endPoint)