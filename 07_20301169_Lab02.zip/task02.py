import sys

sys.stdin = open("input.txt","r")
sys.stdout = open("output2.txt","w")
numbers = int(input())

#Graph constructed by dictionary
graph = {}
endpoint = 0
nodes=0

for counter in range(0, numbers+1):
    if counter==0:
        continue
    elements =list(map(int,input().split()))

    if counter == numbers:
        endpoint = elements[0]
        #print(endPoint)

    if counter == 1:
        nodes = elements[0]
    graph[elements[0]] = elements[1:]
#BFS
Do_visited = [0]*numbers
Do_queue = []

def BFS(graph, endPoint,nodes,Do_visited):
    Do_visited[int(nodes)-1] = 1
    Do_queue.append(nodes)

    while len(Do_queue)!= 0:
        x = Do_queue.pop(0)
        print(x,end=" ")
        if x== int(endPoint):
            break
        for neighbour in graph[int(x)]:
            if Do_visited[int(neighbour)-1] == 0:
                Do_visited[int(neighbour)-1] = 1
                Do_queue.append(neighbour)
BFS(graph,endpoint,nodes,Do_visited)
