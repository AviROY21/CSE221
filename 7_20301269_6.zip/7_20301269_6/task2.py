import sys
import numpy
def LCS(X,Y,Z):
    m,n,o=len(X)+1,len(Y)+1,len(Z)+1
    C=numpy.zeros((m,n,o))
    for i in range(1,m):
        for j in range(1,n):
            for k in range(1,o):
                if Y[j-1]==X[i-1]==Z[k-1]:
                    C[i][j][k]=(C[i-1][j-1][k-1])+1
                else:
                    if C[i-1][j][k]>=C[i][j-1][k]:
                        temp=C[i-1][j][k]
                        if temp>=C[i][j][k-1]:
                            C[i][j][k]=temp
                        else:
                            C[i][j][k]=C[i][j][k - 1]
                    else:
                        temp=C[i][j-1][k]
                        if temp >=C[i][j][k - 1]:
                            C[i][j][k]=temp
                        else:
                            C[i][j][k]=C[i][j][k-1]
    return int(C[len(X)][len(Y)][len(Z)])
sys.stdin=open('input2.txt','r')
sys.stdout=open('output2.txt','w')
a,b,c=input(),input(),input()
print(LCS(a,b,c))