import queue
def schedule(x):
    variable=x[2]
    array=[]
    u=x[1].split()
    for i in range(int(x[0])):
        array.append(int(u[i]))
    array.sort()
    jac1=queue.PriorityQueue()
    sequence=[]
    jack=[]
    jill=[]
    index=0
    for i in variable:
        if i =='J':
            jac1.put(((-1*index),array[index]))
            jack.append(array[index])
            sequence.append(array[index])
            index +=1
        else:
            if i =='j':
                x1=jac1.get()[1]
                jill.append(x1)
                sequence.append(x1)
    sum=0
    sum1=0
    for i in range(len(jack)):
        sum=sum+jack[i]
    for i in range(len(jill)):
        sum1=sum1+jill[i]
    for i in sequence:
        print(i,end='', file=Outputfile)
    print(file=Outputfile)
    print("Jack will work for",sum,'hours', file=Outputfile)
    print("Jill will work for",sum1,'hours', file=Outputfile)


Inputfile=open('task3_input.txt','r')
Outputfile=open('task3_output.txt','w')
p=Inputfile.readlines()
r=schedule(p)
Inputfile.close()
Outputfile.close()




