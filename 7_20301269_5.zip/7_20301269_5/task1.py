import sys
def schedule(D):
    arr= {}
    count= 0
    k=None
    for key in D:
        if count ==0:
            for ar in range(len(D[key])):
                count += 1
                k=key
                arr[key]=D[key][ar]
        else:
            for ar in range(len(D[key])):
                if k <= D[key][ar]:
                    count += 1
                    k=key
                    arr[key]=D[key][ar]

    print(count)
    for key in arr:
        print(arr[key],key)

sys.stdin=open("task1_input.txt",'r')
sys.stdout=open("task1_output.txt",'w')
N=int(input())
tempdict={}

for i in range(N):
    templist=[]
    s,n=input().split()
    s,n=int(s),int(n)

    if n in tempdict.keys():
        templist=tempdict[n]
    templist.append(s)
    tempdict[n]=templist
list1=sorted(tempdict.items())
dict1={}
for n,s in list1:
    dict1[n]=s
schedule(dict1)

