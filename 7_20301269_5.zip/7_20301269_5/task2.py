import sys

def schedule(key,D,m1):
    dict={}
    count=0
    for i in key:
        dict[i]=D[i]
    people= [[]]*m1

    for i in dict:
        for j in dict[i]:
            for k in range(len(people)):
                if len(people[k])==0:
                    people[k]=[i]
                    count +=1
                    break
                elif people[k][-1] <=j:
                    people[k].append(i)
                    count +=1
                    break
    print(count)
sys.stdin=open('task2_input.txt','r')
sys.stdout=open('task2_output.txt','w')
N,M=open("task2_input.txt",'r').readline().split()
dict1={}
list1=[]

for i in range(int(N)+1):
    S_n,F_n=input().split()
    temp=[int(S_n),int(F_n)]
    list1.append(temp)
for i in range(1,len(list1)):
    s_n=list1[i][0]
    f_n=list1[i][1]
    if f_n not in dict1:
        dict1[f_n]=[s_n]
    else:
        dict1[f_n].append(s_n)

keys=sorted(dict1.keys())
schedule(keys,dict1 ,int(M))



